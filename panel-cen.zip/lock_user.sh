#!/bin/bash
passwd -l $1
