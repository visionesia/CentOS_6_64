#!/bin/bash
passwd -u $1
