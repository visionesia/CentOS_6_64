#!/bin/bash
userdel -f -r $1
