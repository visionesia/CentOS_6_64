#!/bin/bash
useradd -M -g Anonymous -s /sbin/nologin $1
echo "$1:$2" | chpasswd
